package com.android.booksapplication;

import android.widget.TextView;

public class ViewHolder {
    TextView title;
    TextView author;
    TextView publisher;
}
