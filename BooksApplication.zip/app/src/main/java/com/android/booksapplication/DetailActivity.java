package com.android.booksapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setTitle(getResources().getString(R.string.detail_info));

        Intent intent = getIntent();
        int num = intent.getIntExtra("num", 0);
        String title = intent.getStringExtra("title");
        String author = intent.getStringExtra("author");
        String publisher = intent.getStringExtra("publisher");
        String summary = intent.getStringExtra("summary");
        int rental = intent.getIntExtra("rental", 0);
        Log.v("Detail", num+", "+title+", "+author+", "+publisher+", "+summary+", "+rental);

        ((TextView)findViewById(R.id.detail_title)).setText("책 제목 : "+title);
        ((TextView)findViewById(R.id.detail_author)).setText("지은이 : "+author);
        ((TextView)findViewById(R.id.detail_publisher)).setText("출판사 : "+publisher);
        ((TextView)findViewById(R.id.detail_summary)).setText("줄거리 : "+summary);
        ((TextView)findViewById(R.id.detail_rental)).setText("대출여부 : "+rental);

    }
}