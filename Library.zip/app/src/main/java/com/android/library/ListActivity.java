package com.android.library;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<BookDTO> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView = (ListView) findViewById(R.id.list);
        ListAdapter listAdapter = new ListAdapter(this.getLayoutInflater(), getList());
        listView.setAdapter(listAdapter);
        // 리스트 내용 클릭 시 이벤트
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ViewHolder viewHolder = (ViewHolder) view.getTag();
                Log.v("listView", viewHolder.title.getText().toString());
                Log.v("listView", viewHolder.author.getText().toString());
                Log.v("listView", viewHolder.publisher.getText().toString());
                Intent intent = new Intent(ListActivity.this, DetailActivity.class);
                intent.putExtra("title", viewHolder.title.getText().toString());
                intent.putExtra("author", viewHolder.author.getText().toString());
                intent.putExtra("publisher", viewHolder.publisher.getText().toString());
                startActivity(intent);
            }
        });
    }

    ArrayList<BookDTO> getList()
    {
        Log.v("select", "getList()");
        String[] columns = new String[]{"title", "author", "publisher"};
        Cursor cursor = getContentResolver()
                .query(MyContentProvider.URI, columns, null, null, null);
        list = new ArrayList<BookDTO>();

        if (cursor != null)
        {
            while (cursor.moveToNext())
            {
                list.add(new BookDTO(cursor.getString(0), cursor.getString(1), cursor.getString(2)));
                Log.v("select", cursor.getString(0));
                Log.v("select", cursor.getString(1));
                Log.v("select", cursor.getString(2));
            }
        }
        return list;
    }
}