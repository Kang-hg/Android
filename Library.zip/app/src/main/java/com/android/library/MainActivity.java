package com.android.library;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    Button btn_list;
    Button btn_add;
    EditText edit_title;
    EditText edit_author;
    EditText edit_publisher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_list = (Button) findViewById(R.id.button_list);
        btn_add = (Button) findViewById(R.id.button_add);
        btn_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ListActivity.class);
                startActivity(intent);
            }
        });
        edit_title = (EditText) findViewById(R.id.edit_title);
        edit_author = (EditText) findViewById(R.id.edit_author);
        edit_publisher = (EditText) findViewById(R.id.edit_publisher);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("insert", "저장");
                ContentValues cv = new ContentValues();
                cv.put("title", edit_title.getText().toString());
                cv.put("author", edit_author.getText().toString());
                cv.put("publisher", edit_publisher.getText().toString());
                getContentResolver().insert(MyContentProvider.URI, cv);
                edit_title.setText("");
                edit_author.setText("");
                edit_publisher.setText("");
                edit_title.requestFocus();
                Log.v("insert", "저장 완료");
            }
        });
    }
}














