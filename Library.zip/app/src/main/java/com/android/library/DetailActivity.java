package com.android.library;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView text_title;
    TextView text_author;
    TextView text_publisher;
    TextView text_rental;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String author = intent.getStringExtra("author");
        String publisher = intent.getStringExtra("publisher");
        String rental = "대출가능";
        text_title = (TextView) findViewById(R.id.detail_title);
        text_author = (TextView) findViewById(R.id.detail_author);
        text_publisher = (TextView) findViewById(R.id.detail_publisher);
        text_rental = (TextView) findViewById(R.id.detail_rental);
        text_title.setText(title);
        text_author.setText(author);
        text_publisher.setText(publisher);
        text_rental.setText(rental);
    }
}