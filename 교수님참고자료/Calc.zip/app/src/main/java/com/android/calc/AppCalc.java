package com.android.calc;

public interface AppCalc {
    double calc(double n1, double n2);
}
