package com.android.serviceapplication2;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

public class DivisionService2 extends Service {

    static final int MSG_DIVISION3 = 30;
    Messenger messenger;

    private final IBinder mBinder = new DivisionService2.DivisionBinder2();
    private double result;

    public class DivisionBinder2 extends Binder {
        public double getResult() {
            return result;
        }
    }

    public DivisionService2() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i("onBind intentAction", intent.getAction());
        if (intent.getAction().equals("DivisionService2")) {
            Bundle extras = intent.getExtras();
            if (extras != null) {
                CalcNum calcNum = (CalcNum) extras.get("data");
                calcNum.setResult(calcNum.getNum1() / calcNum.getNum2());
                result = calcNum.getResult();
                messenger = (Messenger) extras.get("messenger");
                Message msg = Message.obtain();
                msg.arg1 = Activity.RESULT_OK;
                msg.what = MSG_DIVISION3;
                msg.obj = calcNum;
                try {
                    messenger.send(msg);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
        return mBinder;
    }
}