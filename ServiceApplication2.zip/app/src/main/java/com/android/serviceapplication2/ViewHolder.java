package com.android.serviceapplication2;

import android.widget.TextView;

public class ViewHolder {

    public TextView num1;
    public TextView num2;
    public TextView result;

}
