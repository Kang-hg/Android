package com.android.serviceapplication2;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    final static String SERVICE_MULTIPLY = "com.android.serviceapplication2.MultiplyService";
    final static String SERVICE_MULTIPLY2 = "com.android.serviceapplication2.MultiplyService2";
    final static String SERVICE_DIVISION = "com.android.serviceapplication2.DivisionService";
    final static String SERVICE_DIVISION2 = "com.android.serviceapplication2.DivisionService2";


    TextView result;
    CalcNum calcNum;
    MultiplyService mService;
    boolean mBound = false;
    Messenger messengerService;
    ArrayList<CalcNum> list;
    static int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = (TextView) findViewById(R.id.result);
    }

    private CalcNum getCalcNum()
    {
        double d1 = Double.parseDouble(((EditText)findViewById(R.id.num1)).getText().toString());
        double d2 = Double.parseDouble(((EditText)findViewById(R.id.num2)).getText().toString());
        return new CalcNum(d1, d2);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_plus:
                Log.i("onClick", "plus");
                Intent intent = new Intent(this, PlusService.class);
                calcNum = getCalcNum();
                intent.putExtra("data", calcNum);
                startService(intent);
                count++;
                break;
            case R.id.btn_plus_result:
                Log.i("onClick", "plus_result : "+CalcNum.result2);
                break;
            case R.id.btn_minus:
                Log.i("onClick", "minus");
                // 첫 번째 방식
                Intent intent1 = new Intent(this, MinusService.class);
                intent1.setAction(MinusService.ACTION_FOO);
                Messenger messenger = new Messenger(handler);
                intent1.putExtra("messenger", messenger);
                calcNum = getCalcNum();
                intent1.putExtra("data", calcNum);
                startService(intent1);

                // 두 번째 방식
                Bundle bundle = new Bundle();
                bundle.putDouble("num1", calcNum.getNum1());
                bundle.putDouble("num2", calcNum.getNum2());
                MinusService.startActionBaz(getApplicationContext(), messenger, bundle);
                break;
            case R.id.btn_multiply:
                Log.i("onClick", "multiply");
                if (mBound) {
                    // 첫 번째 방식
                    calcNum = getCalcNum();
                    double resultNum = mService.getMultiply(calcNum.getNum1(), calcNum.getNum2());
                    Log.i("multiply", resultNum+"");
                    result.setText("결과 : "+resultNum);

                    // 두 번째 방식
                    Intent intent2 = new Intent(this, MultiplyService2.class);
                    intent2.putExtra("num1", calcNum.getNum1());
                    intent2.putExtra("num2", calcNum.getNum2());
                    bindService(intent2, mConnection, Context.BIND_AUTO_CREATE);
                }
                break;
            case R.id.btn_division:
                Log.i("onClick", "division");
                if (!mBound) return;
                calcNum = getCalcNum();
                // 1번째 방식
                Message msg = Message.obtain();
                msg.what = DivisionService.MSG_DIVISION;
                msg.obj = calcNum;
                try {
                    messengerService.send(msg);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                // 2번째 방식
                Message msg2 = Message.obtain();
                msg2.what = DivisionService.MSG_DIVISION2;
                Bundle bundle1 = new Bundle();
                Messenger messenger2 = new Messenger(handler);
                bundle1.putBinder("messenger", messenger2.getBinder());
                bundle1.putDouble("num1", calcNum.getNum1());
                bundle1.putDouble("num2", calcNum.getNum2());
                msg2.obj = bundle1;
                try {
                    messengerService.send(msg2);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                // 3번째 방식
                Intent intent3 = new Intent(this, DivisionService2.DivisionBinder2.class);
                intent3.setAction("DivisionService2");
                Messenger messenger3 = new Messenger(handler);
                intent3.putExtra("messenger", messenger3);
                calcNum = getCalcNum();
                intent3.putExtra("data", calcNum);
                bindService(intent3, mConnection, Context.BIND_AUTO_CREATE);
                break;
            case R.id.btn_list:
                Intent intent4 = new Intent(this, ListActivity.class);
                startActivity(intent4);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        // 덧셈 2번째 방식, 나눗셈 1번째 방식
        result.setText("결과 : "+intent.getStringExtra("result"));
        super.onNewIntent(intent);
    }

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.arg1 == RESULT_OK && msg.obj != null) {
                switch (msg.what) {
                    case MinusService.ACTION_01:
                        CalcNum calcNum = (CalcNum) msg.obj;
                        result.setText("결과 : "+calcNum.getResult());
                        break;
                    case MinusService.ACTION_02:
                        Log.i("minus", "뺄셈 결과 : "+msg.obj);
                        break;
                    case DivisionService.MSG_DIVISION2: // 나누기 2번째 방식
                        Log.i("division", "나눗셈 결과2 : "+msg.obj);
                        break;
                    case DivisionService2.MSG_DIVISION3:    // 나누기 3번째 방식
                        CalcNum calcNum2 = (CalcNum) msg.obj;
                        Log.i("division2", "나눗셈 결과 3-1 : "+calcNum2.getResult());
                        break;
                }
            }
        }
    };

    @Override
    protected void onStart() {
        Log.i("activity", "onStart()");
        Intent intent2 = new Intent(this, MultiplyService.class);
        intent2.putExtra("msg", "곱하기 계산하기");
        bindService(intent2, mConnection, Context.BIND_AUTO_CREATE);
        super.onStart();

        // 나누기 1,2번째 방식
        bindService(new Intent(this, DivisionService.class), mConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        Log.i("activity", "onStop()");
        if (mBound) {
            unbindService(mConnection);
            mBound = false;
        }
        super.onStop();
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.i("activity", "onServiceConnected() "+componentName.getClassName());
            switch (componentName.getClassName()) {
                case SERVICE_MULTIPLY:
                    MultiplyService.MultiplyBinder binder = (MultiplyService.MultiplyBinder) iBinder;
                    mService = binder.getService();
                    mBound = true;
                    break;
                case SERVICE_MULTIPLY2:
                    MultiplyService2.MultiplyBinder2 binder2 = (MultiplyService2.MultiplyBinder2) iBinder;
                    Log.i("SERVICE_MULTIPLY2", "곱셈 결과 : "+binder2.getResult());
                    break;
                case SERVICE_DIVISION:  // 나누기 1,2번째 방식
                    Log.i("SERVICE_DIVISION", "divisionService bind");
                    messengerService = new Messenger(iBinder);
                    mBound = true;
                    break;
                case SERVICE_DIVISION2: // 나누기 3번째 방식
                    Log.i("SERVICE_DIVISION2", "divisionService2 bind");
                    unbindService(mConnection);
                    DivisionService2.DivisionBinder2 binder3 = (DivisionService2.DivisionBinder2) iBinder;
                    Log.i("SERVICE_DIVISION2", "나눗셈 결과 3-2 : "+binder3.getResult());
                    break;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.i("activity", "onServiceDisconnected()");
            mBound = false;
        }
    };
}












