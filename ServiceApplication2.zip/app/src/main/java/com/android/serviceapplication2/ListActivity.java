package com.android.serviceapplication2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<CalcNum> list;
    CalcNum calcNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView = (ListView) findViewById(R.id.list);
        ListAdapter listAdapter = new ListAdapter(this.getLayoutInflater(), getList());
        listView.setAdapter(listAdapter);
    }

    ArrayList<CalcNum> getList() {
        list = new ArrayList<CalcNum>();

        for (int i=0; i<MainActivity.count; i++) {
            list.add(calcNum);
        }
        return list;
    }
}