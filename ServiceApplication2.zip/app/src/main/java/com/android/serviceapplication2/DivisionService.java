package com.android.serviceapplication2;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.util.Log;

public class DivisionService extends Service {

    static final int MSG_DIVISION = 10;
    static final int MSG_DIVISION2 = 20;
    final Messenger mMessenger = new Messenger(new IncomingHandler());

    class IncomingHandler extends Handler {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case MSG_DIVISION:  // 나누기 1번째 방식
                    Log.i("DivisionService", "MSG_DIVISION");
                    CalcNum calcNum = (CalcNum) msg.obj;
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    );
                    intent.putExtra("result", calcNum.getNum1() / calcNum.getNum2()+"");
                    startActivity(intent);
                    break;
                case MSG_DIVISION2: // 나누기 2번째 방식
                    Log.i("DivisionService", "MSG_DIVISION2");
                    Bundle bundle = (Bundle) msg.obj;
                    Messenger messenger = new Messenger(bundle.getBinder("messenger"));
                    Message message = Message.obtain();
                    message.what = MSG_DIVISION2;
                    message.arg1 = Activity.RESULT_OK;
                    message.obj = bundle.getDouble("num1") / bundle.getDouble("num2");
                    try {
                        messenger.send(message);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                    break;
                default:
                    super.handleMessage(msg);
            }
        }
    }

    public DivisionService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mMessenger.getBinder();
    }
}